from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from models import db, User, Product, Purchase, Submission, Certificate
import os
import uuid

app = Flask(__name__)
app.config['SECRET_KEY'] = 'briticana_secret_key'
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'briticana.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    products = Product.query.all()
    domains = sorted(list(set([p.domain for p in products])))
    internships = [p for p in products if p.category == 'Internship']
    projects = [p for p in products if p.category == 'Project']
    tasks = [p for p in products if p.category == 'Task']
    return render_template('index.html', internships=internships, projects=projects, tasks=tasks, domains=domains)

@app.route('/domain/<string:domain_name>')
def domain_page(domain_name):
    products = Product.query.filter_by(domain=domain_name).all()
    if not products:
        flash("Domain not found or has no products.")
        return redirect(url_for('index'))
    internships = [p for p in products if p.category == 'Internship']
    projects = [p for p in products if p.category == 'Project']
    tasks = [p for p in products if p.category == 'Task']
    return render_template('domain.html', domain_name=domain_name, internships=internships, projects=projects, tasks=tasks)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        unique_code = request.form.get('unique_code')
        # Here we would check if code is valid and user exists
        # For demo purposes, we will mock auth
        user = User.query.filter_by(unique_code=unique_code).first()
        if user:
            session['user_id'] = user.id
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid Code')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = User.query.get(session['user_id'])
    purchases = Purchase.query.filter_by(user_id=user.id).order_by(Purchase.id.desc()).all()
    return render_template('dashboard.html', user=user, purchases=purchases)

@app.route('/submit/<int:purchase_id>', methods=['POST'])
def submit_task(purchase_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    purchase = Purchase.query.get_or_404(purchase_id)
    if purchase.user_id != session['user_id']:
        flash("Unauthorized")
        return redirect(url_for('dashboard'))
    
    github_link = request.form.get('github_link')
    if github_link:
        purchase.status = 'Completed'
        
        # Create Submission
        submission = Submission(user_id=purchase.user_id, product_id=purchase.product_id, github_link=github_link)
        db.session.add(submission)
        
        # Check for existing cert or create one
        cert = Certificate.query.filter_by(user_id=purchase.user_id, product_id=purchase.product_id).first()
        if not cert:
            import uuid
            cert_code = f"CERT-BRIT-{str(uuid.uuid4())[:8].upper()}"
            cert = Certificate(cert_code=cert_code, user_id=purchase.user_id, product_id=purchase.product_id)
            db.session.add(cert)
            
        db.session.commit()
        
        # Instantly show the certificate!
        return redirect(url_for('view_certificate', cert_code=cert.cert_code))
        
    flash("Please provide a valid GitHub link.")
    return redirect(url_for('dashboard'))

@app.route('/details/<int:product_id>')
def details(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template('details.html', product=product)

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        title = request.form.get('title')
        category = request.form.get('category')
        domain = request.form.get('domain')
        price = float(request.form.get('price', 0))
        description = request.form.get('description')
        procedure = request.form.get('procedure')
        achievements = request.form.get('achievements')
        
        new_product = Product(
            title=title, category=category, domain=domain, price=price,
            description=description, procedure=procedure, achievements=achievements
        )
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('admin'))
        
    products = Product.query.order_by(Product.id.desc()).all()
    users = User.query.all()
    return render_template('admin.html', products=products, users=users)

@app.route('/admin/delete/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return redirect(url_for('admin'))

@app.route('/verification')
def verification():
    cert_code = request.args.get('cert_code')
    certificate = None
    if cert_code:
        # Strip any accidental whitespace or trailing text the user might paste
        cert_code = cert_code.strip()
        certificate = Certificate.query.filter_by(cert_code=cert_code).first()
    return render_template('verification.html', certificate=certificate, cert_code=cert_code)

@app.route('/certificate/<cert_code>')
def view_certificate(cert_code):
    certificate = Certificate.query.filter_by(cert_code=cert_code).first_or_404()
    return render_template('certificate.html', certificate=certificate)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
